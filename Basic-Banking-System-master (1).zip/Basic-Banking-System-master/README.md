# The Sparks Foundation Internship Project
## Basic Banking System
### Tools : XAMPP, Visual Studio Code, Git.
### Technologies : HTML, Bootstrap, PHP,SQL.
